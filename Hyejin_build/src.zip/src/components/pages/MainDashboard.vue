<template>
    <div class="dashboard">
      <h2>Sales Dashboard</h2>
    </div>
  </template>
  
  <script setup>
  </script>
  
  <style scoped>
  .dashboard {
    padding: 20px;
  }
  </style>